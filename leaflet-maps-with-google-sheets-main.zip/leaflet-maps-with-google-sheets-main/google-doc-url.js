// paste in your published Google Sheets URL from the browser address bar
var googleDocURL = 'https://docs.google.com/spreadsheets/d/17QbAPdFTaBzYZSIGeeLkt38atj9qq9hJGxGI2JvUmAE/edit#gid=0';

// insert your own Google Sheets API key from https://console.developers.google.com
var googleApiKey = 'AIzaSyBh9nKnVZm2RPeZa0ywCOxPAgJJfK87WhY';
